//------according the sample-------------------------------------
var http = require('http');
var WebSocketServer = require('websocket').server;
var server = http.createServer(function(request, response) {});
server.listen(1337, function() { });
wsServer = new WebSocketServer({
    httpServer: server
});
//--end-according the sample-------------------------------------


var clients = [ ];
var goods = [ ];

function GUID ()
{
    var S4 = function ()
    {
        return Math.floor(
                Math.random() * 0x10000 /* 65536 */
            ).toString(16);
    };

    return (
            S4() + S4() + "-" +
            S4() + "-" +
            S4() + "-" +
            S4() + "-" +
            S4() + S4() + S4()
        );
}

wsServer.on('request', function(request) {
	var connection = request.accept(null, request.origin);
	var guid = GUID();
	clients.push({connection : connection, id: guid});
	console.log("Client:'" + guid + "' was connected (new clients count:" + clients.length + ")");
	connection.sendUTF(JSON.stringify( { type: 'ListOfGoods', goods: goods, id: guid} ));

	connection.on('message', function(message) {
		if(message.type != 'utf8'){
			console.log("unknown message type: " + message.type);
			return;
		}
		try {
		    var json = JSON.parse(message.utf8Data);
		} catch (e) {
		    console.log('This doesn\'t look like a valid JSON: ', message.utf8Data);
		    return;
		}
		console.log("message from client:'" + json.idClient + "' was parsed (message type:'" + json.type + "')");
		
		switch(json.type){
			case "bet":
				var good = false;
				for(var i in goods)
					if(goods[i].id == json.idGood){
						goods[i].price = (goods[i].price * 1.05).toFixed(2);
						goods[i].idSeller = json.idClient;
						good = goods[i];
					}
				
				if(!good) return;
				var msg = JSON.stringify( { type: 'bet', good: good});
				for(var i in clients){
				    clients[i].connection.sendUTF(msg);
				}			
			break;
			case "addGood":
				var guid = GUID();
				var newgood = {id:guid, title:json.title, price : json.price, idOwner: json.idClient, idSeller: json.idClient};
				goods.push(newgood);
				var mymsg = JSON.stringify( { type: 'myGoodAdded', good: newgood });
				var othermsg = JSON.stringify( { type: 'goodAdded', good: newgood });
				for (var i in clients) {
					clients[i].connection.sendUTF(othermsg);
					if(clients[i].id == newgood.idOwner)
						clients[i].connection.sendUTF(mymsg);
				}

			break;
			case "remGood":		
				var remgood;		
				for(var i in goods){
					if(goods[i].id == json.idGood){
						remgood = goods[i];
						goods.splice(i, 1);
						break;
					}						
				}
				var mymsg = JSON.stringify( { type: 'myGoodRemoved', idGood: json.idGood });				
				for (var i in clients) {
					var othermsg = JSON.stringify( { type: 'goodRemoved', good: remgood});
					clients[i].connection.sendUTF(othermsg);
					if(clients[i].id == json.idClient)
						clients[i].connection.sendUTF(mymsg);
				}
			break;
		}
	});

	connection.on('close', function(connection) {
		for(var i in clients)		
			if(clients[i].id == guid){
				clients.splice(i, 1);
				break;
			}		
		console.log("Client:'" + guid + "' was disconnected (new clients count:" + clients.length + ")");
	});
});

