var conn = {};
$(function () {
	    // if user is running mozilla then use it's built-in WebSocket
	    window.WebSocket = window.WebSocket || window.MozWebSocket;
	    var connection = new WebSocket('ws://127.0.0.1:1337');
	    conn = connection;
	    connection.onopen = function () {
	    };

	    connection.onerror = function (error) {
		alert(error);
		console.log(error);
	    };

	    $(".good-add").click(function(){
		var goodName = $("#goodName").val();
		var goodPrice = $("#goodPrice").val();
		if(goodName.length == 0 || goodPrice.length == 0){
			alert("Error! There is empty field!!!");
			return;
		}
		$("#goodName").val("");
		$("#goodPrice").val("");
		connection.send(JSON.stringify({type:"addGood", idClient:$("#myid").text(), title:goodName, price: goodPrice}));
	    });

	    connection.onmessage = function (message) {
		try {
		    var json = JSON.parse(message.data);
		} catch (e) {
		    alert("parse error")
		    console.log('This doesn\'t look like a valid JSON: ', message.data);
		    return;
		}
		switch(json.type)
		{
			case 'ListOfGoods':
				$("#myid").text(json.id);
				var table = $("#goodsTable");				
				for(var i in json.goods)
				{
					var tr = $("<tr></tr>");
					tr.append($("<td>" + json.goods[i].title + "</td>"));
					tr.append($("<td data-idgood='" + json.goods[i].id + "'>" + json.goods[i].price + "</td>"));
					var btn = $("<button class='btn'>Bet</button>");
					btn.data("idGood", json.goods[i].id);
					btn.data("idClient", $("#myid").text());
					btn.click(function(){
						idClient = $(this).data("idClient");
						idGood = $(this).data("idGood");
						connection.send(JSON.stringify({type:"bet", idClient:idClient, idGood:idGood}));
					});
					var td = $("<td></td>");
					td.append(btn);
					tr.append(td);
					table.append(tr);
				}
			break;
			case 'bet':
				$("td[data-idgood='" + json.good.id + "']").text(json.good.price);
				if($("#myid").text() == json.good.idOwner){
					$("td[data-myidgood='" + json.good.id + "']").text(json.good.price);
				}
				if($("#myid").text() == json.good.idSeller){
					$("td[data-idgood='" + json.good.id + "']").css('color','green');
				
				}
				else{
					$("td[data-idgood='" + json.good.id + "']").css('color','black');
				}
			break;
			case 'myGoodAdded':
				var table = $('#myGoods');
				var tr = $("<tr></tr>");
				var tdTitle = $("<td>" + json.good.title + "</td>");
				var tdPrice = $("<td data-myidgood='" + json.good.id + "'>" + json.good.price + "</td>");
				var stopbtn = $("<button class='btn btn-danger'>Stop</button>");
				stopbtn.data("idGood", json.good.id);
				stopbtn.data("idClient", json.good.idOwner);
				stopbtn.click(function(){
					idClient = $(this).data("idClient");
					idGood = $(this).data("idGood");
					conn.send(JSON.stringify({type:"remGood", idClient:idClient, idGood:idGood}));
				});
				var tdStop = $("<td></td>");
				tdStop.append(stopbtn);
				tr.append(tdTitle);
				tr.append(tdPrice);
				tr.append(tdStop);
				table.append(tr);
			break;
			case 'goodAdded':
				var table = $('#goodsTable');
				var tr = $("<tr></tr>");
				tr.append($("<td>" + json.good.title + "</td>"));
				var pricetd = $("<td data-idgood='" + json.good.id + "'>" + json.good.price + "</td>");
				if($("#myid").text() == json.good.idSeller){
					pricetd.css('color','green');
				}
				else{
					pricetd.css('color','black');
				}
				tr.append(pricetd);
				var btn = $("<button class='btn'>Bet</button>");
				btn.data("idGood", json.good.id);
				btn.data("idClient", $("#myid").text());
				btn.click(function(){
					idClient = $(this).data("idClient");
					idGood = $(this).data("idGood");
					conn.send(JSON.stringify({type:"bet", idClient:idClient, idGood:idGood}));
				});
				var td = $("<td></td>");
				td.append(btn);
				tr.append(td);
				table.append(tr);					
			break;
			case 'myGoodRemoved':
				$("td[data-myidgood='" + json.idGood + "']").parent().remove();
			break;
			case 'goodRemoved':
				$("td[data-idgood='" + json.good.id + "']").parent().remove();
				if(json.good.idSeller == $("#myid").text()){
					alert("You buy good:'" + json.good.title + "' for " + json.good.price + "$");
				}

				
			break;
		}
	    };
	});
